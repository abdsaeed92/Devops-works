// @@@SNIPSTART hello-world-project-template-java-shared-constants
package helloworldapp;

public interface Shared {

    // Define the task queue name
    final String HELLO_WORLD_TASK_QUEUE = "HelloWorldTaskQueue";

}
// @@@SNIPEND
